import 'core-js/stable';
import 'whatwg-fetch';
import 'abortcontroller-polyfill/dist/abortcontroller-polyfill-only';
import 'pepjs';

function report(message) {
  var native = window.PatrulhaAndroid;
  if (native && native.error) native.error(String(message));
  var box = document.getElementById('loading');
  if (box) { box.style.display = 'block'; box.textContent = 'Não foi possível abrir a aventura: ' + message; }
}
window.addEventListener('error', function(event) { report(event.message || 'Falha ao carregar o jogo'); });
window.addEventListener('unhandledrejection', function(event) { report(String(event.reason || 'Falha no jogo')); });

if (!Element.prototype.matches) Element.prototype.matches = Element.prototype.webkitMatchesSelector || Element.prototype.msMatchesSelector;
if (!Element.prototype.closest) Element.prototype.closest = function(selector) {
  var item = this;
  while (item && item.nodeType === 1) { if (item.matches(selector)) return item; item = item.parentElement; }
  return null;
};
if (!document.elementsFromPoint) document.elementsFromPoint = function(x, y) {
  var found = [], hidden = [], item, i;
  try {
    while ((item = document.elementFromPoint(x, y)) && found.length < 24) {
      if (found.indexOf(item) >= 0 || item === document.body || item === document.documentElement) break;
      found.push(item); hidden.push(item.style.visibility); item.style.visibility = 'hidden';
    }
  } finally { for (i = 0; i < found.length; i++) found[i].style.visibility = hidden[i]; }
  return found;
};
if (!window.performance) window.performance = {};
if (!window.performance.now) { var startTime = Date.now(); window.performance.now = function() { return Date.now() - startTime; }; }
if (!window.requestAnimationFrame) window.requestAnimationFrame = window.webkitRequestAnimationFrame || function(fn) { return setTimeout(function() { fn(window.performance.now()); }, 16); };
if (!window.cancelAnimationFrame) window.cancelAnimationFrame = window.webkitCancelAnimationFrame || clearTimeout;
if (!AbortSignal.timeout) AbortSignal.timeout = function(ms) { var controller = new AbortController(); setTimeout(function() { controller.abort(); }, ms); return controller.signal; };
var Audio = window.AudioContext || window.webkitAudioContext;
if (Audio) {
  if (!Audio.prototype.createGain && Audio.prototype.createGainNode) Audio.prototype.createGain = Audio.prototype.createGainNode;
  var originalOscillator = Audio.prototype.createOscillator;
  if (originalOscillator) Audio.prototype.createOscillator = function() {
    var oscillator = originalOscillator.call(this);
    if (!oscillator.start && oscillator.noteOn) oscillator.start = oscillator.noteOn.bind(oscillator);
    if (!oscillator.stop && oscillator.noteOff) oscillator.stop = oscillator.noteOff.bind(oscillator);
    return oscillator;
  };
}

if (!window.speechSynthesis && window.PatrulhaAndroid) {
  window.SpeechSynthesisUtterance = function(text) { this.text = text; this.lang = 'pt-BR'; };
  window.speechSynthesis = {
    getVoices: function() { return [{ voiceURI:'android-pt-BR', name:'Voz do tablet', lang:'pt-BR', localService:true, default:true }]; },
    speak: function(utterance) { window.PatrulhaAndroid.speak(utterance.text); },
    cancel: function() { window.PatrulhaAndroid.stop(); },
    addEventListener: function() {}, removeEventListener: function() {}
  };
}

window.PatrulhaViewport = function() {
  document.documentElement.style.height = window.innerHeight + 'px';
  document.body.style.height = window.innerHeight + 'px';
  document.getElementById('root').style.height = window.innerHeight + 'px';
};
window.addEventListener('resize', window.PatrulhaViewport);
window.PatrulhaViewport();

function touchTargets() {
  var targets = document.querySelectorAll('.touch-none,.touch-pan-y');
  for (var i = 0; i < targets.length; i++) {
    var action=targets[i].className.indexOf('touch-pan-y') >= 0 ? 'pan-y' : 'none';
    if(targets[i].getAttribute('touch-action') !== action) targets[i].setAttribute('touch-action', action);
  }
  var images=document.querySelectorAll('svg image');
  for(i=0;i<images.length;i++) {
    var href=images[i].getAttribute('href');
    if(href && images[i].getAttributeNS('http://www.w3.org/1999/xlink','href') !== href) images[i].setAttributeNS('http://www.w3.org/1999/xlink','xlink:href',href);
  }
}
var Observer = window.MutationObserver || window.WebKitMutationObserver;
if (Observer) new Observer(touchTargets).observe(document.getElementById('root'), { childList:true, subtree:true, attributes:true, attributeFilter:['href'] });
else setInterval(touchTargets, 100);

try {
  require('./staging/src/main.tsx');
  setTimeout(function() {
    touchTargets();
    var root = document.getElementById('root');
    if (!root.firstChild) { report('A tela inicial não foi desenhada.'); return; }
    document.getElementById('loading').style.display = 'none';
    if (window.PatrulhaAndroid) window.PatrulhaAndroid.ready();
  }, 1000);
} catch (error) { report(error && error.stack || String(error)); }
