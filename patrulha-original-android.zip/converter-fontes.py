from pathlib import Path
from fontTools.ttLib import TTFont
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent / "assets"
for path in (base / "fonts").glob("*.woff"):
    font = TTFont(path)
    font.flavor = None
    font.save(path.with_suffix(".ttf"))
css = base / "game.css"
css.write_text(css.read_text().replace('.woff"', '.ttf"').replace('format("woff")', 'format("truetype")'))
print("Fontes locais convertidas para TrueType.")
illustrations=base / "illustrations"
black=illustrations / "black"
black.mkdir(exist_ok=True)
for original in illustrations.glob("*.svg"):
    tree=ET.parse(original)
    for element in tree.iter():
        for attribute in ("fill", "stroke"):
            value=element.get(attribute)
            if value and value not in ("none", "transparent"):
                element.set(attribute,"#000000")
    tree.write(black/original.name,encoding="utf-8",xml_declaration=True)
print("Silhuetas SVG geradas para os jogos originais.")
