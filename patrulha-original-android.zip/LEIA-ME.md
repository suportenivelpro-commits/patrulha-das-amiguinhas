# Patrulha das Amiguinhas original — versão de compatibilidade em preparação

Este pacote compila o código do repositório original `suportenivelpro-commits/patrulha-das-amiguinhas`. Não inclui o aplicativo de perguntas criado antes. O código original dos minijogos, das personagens, dos veículos e do catálogo de 50 missões é copiado para uma pasta temporária durante a compilação.

A adaptação troca a camada de renderização por Preact compat, transpila o JavaScript para ES5, inclui suporte a toques e converte os estilos e fontes para formatos mais antigos. O APK abre esses arquivos localmente no WebView do Android, com narração pela voz instalada no tablet. A porta local fixa preserva a origem do armazenamento do progresso.

## O que ainda precisa ser confirmado

Esta é uma versão de teste. A compilação completa ainda não foi executada neste ambiente. O fluxo do GitHub verifica a sintaxe ES5, percorre a tela inicial, o mapa, a escolha da heroína, a viagem e o resgate do gatinho num navegador atual com alguns recursos nativos desativados. Salva capturas das telas. Isso não comprova o funcionamento no WebKit do Android 4.2.2: os estilos, os toques, o áudio e os demais jogos precisam ser conferidos no SM-T111M.

A conta online depende também do HTTPS oferecido pelo sistema antigo e não foi validada. O progresso sem conta usa o armazenamento do aplicativo; não migra automaticamente o progresso do site nem do aplicativo de perguntas anterior. Não desinstale uma versão com progresso importante durante os testes. Este aplicativo tem outro identificador e pode coexistir com o anterior.

## Como usar pelo GitHub

1. Envie `patrulha-original-android.zip` para a raiz do repositório original `patrulha-das-amiguinhas`.
2. Substitua o conteúdo de `.github/workflows/android-compatibilidade.yml` pelo arquivo `gerar-apk-original.yml` incluído neste pacote.
3. Confirme o commit. Na aba Actions, acompanhe **Gerar APK Original**.
4. Em Artifacts, baixe **Patrulha-Original-Android**. Confira primeiro as capturas das telas. Se a compilação e a assinatura concluírem, haverá também `patrulha-original-android-4.2.2.apk`.
5. Instale o APK no tablet para validar a versão de compatibilidade. Em caso de erro, o aplicativo exibe uma mensagem para diagnóstico, em vez de permanecer em branco.

As ilustrações e seus créditos são copiados de `public/` do projeto original. As fontes mantêm suas licenças. A assinatura de teste é gerada na pasta privada do executor, e a chave não é publicada como artefato. Uma execução posterior cria outra chave; para atualizações que preservem o progresso, será necessário manter uma chave de assinatura estável.
