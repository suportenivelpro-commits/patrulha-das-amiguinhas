package br.com.patrulhadasamiguinhas.original;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.*;
import java.net.*;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Original game assets served exclusively on loopback, with Android 4.2 APIs. */
public class MainActivity extends Activity {
    private static final int PORT = 43717;
    private static final String ORIGIN = "http://127.0.0.1:" + PORT + "/";
    private WebView web;
    private TextView status;
    private ServerSocket server;
    private ExecutorService pool;
    private volatile boolean closed;
    private TextToSpeech tts;
    private boolean voiceReady, foreground;
    private String pendingVoice;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(248, 233, 252));
        status = new TextView(this);
        status.setText("Abrindo a aventura…");
        status.setTextSize(18);
        status.setTextColor(Color.rgb(76, 40, 83));
        status.setPadding(18, 18, 18, 18);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(248, 233, 252));
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setDatabasePath(getDir("web-database", MODE_PRIVATE).getPath());
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setTextZoom(100);
        web.addJavascriptInterface(new VoiceBridge(), "PatrulhaAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return !url.startsWith(ORIGIN);
            }
            @Override public void onPageFinished(WebView v, String url) {
                v.loadUrl("javascript:if(window.PatrulhaViewport){window.PatrulhaViewport();}");
            }
            @Override public void onReceivedError(WebView v, int code, String description, String url) {
                showError("Não foi possível abrir a aventura.\n" + description);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR)
                    showError("Erro ao abrir o jogo neste tablet:\n" + message.message() + "\nLinha " + message.lineNumber());
                return true;
            }
        });
        try {
            startServer();
            web.loadUrl(ORIGIN);
        } catch (IOException e) { showError("Não foi possível iniciar a aventura. Feche e abra o aplicativo.\n" + e.getMessage()); }
    }

    private void showError(final String text) {
        runOnUiThread(new Runnable() { @Override public void run() {
            if (!isFinishing()) { status.setVisibility(View.VISIBLE); status.setText(text); }
        }});
    }

    private void startServer() throws IOException {
        server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT));
        pool = Executors.newFixedThreadPool(4);
        new Thread(new Runnable() { @Override public void run() {
            while (!closed) try {
                final Socket socket = server.accept();
                pool.execute(new Runnable() { @Override public void run() { serve(socket); }});
            } catch (IOException e) { if (!closed) showError("A conexão local do jogo foi interrompida."); }
        }}, "patrulha-assets").start();
    }

    private void serve(Socket socket) {
        InputStream data = null;
        try {
            socket.setSoTimeout(10000);
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), "US-ASCII"));
            String request = reader.readLine();
            if (request == null || request.length() > 4096) return;
            String[] parts = request.split(" ");
            if (parts.length != 3 || !"GET".equals(parts[0])) { send(socket, 405, "text/plain", "Método não permitido".getBytes("UTF-8")); return; }
            for (int i = 0; i < 64; i++) { String line = reader.readLine(); if (line == null || line.length() == 0) break; }
            String path = URLDecoder.decode(parts[1].split("\\?", 2)[0], "UTF-8");
            if (!path.startsWith("/") || path.indexOf("..") >= 0 || path.indexOf('\\') >= 0 || path.indexOf(0) >= 0) {
                send(socket, 403, "text/plain", new byte[0]); return;
            }
            path = "/".equals(path) ? "index.html" : path.substring(1);
            try { data = getAssets().open(path); } catch (IOException missing) { send(socket, "favicon.ico".equals(path) ? 204 : 404, "text/plain", new byte[0]); return; }
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192]; int count;
            while ((count = data.read(buffer)) != -1) bytes.write(buffer, 0, count);
            String mime = path.endsWith(".html") ? "text/html; charset=utf-8" : path.endsWith(".js") ? "application/javascript; charset=utf-8" : path.endsWith(".css") ? "text/css; charset=utf-8" : path.endsWith(".svg") ? "image/svg+xml" : path.endsWith(".png") ? "image/png" : path.endsWith(".woff") ? "application/font-woff" : path.endsWith(".ttf") ? "application/x-font-ttf" : "application/octet-stream";
            send(socket, 200, mime, bytes.toByteArray());
        } catch (IOException ignored) {
        } finally {
            if (data != null) try { data.close(); } catch (IOException ignored) { }
            try { socket.close(); } catch (IOException ignored) { }
        }
    }

    private void send(Socket socket, int code, String mime, byte[] bytes) throws IOException {
        OutputStream out = socket.getOutputStream();
        String headers = "HTTP/1.1 " + code + " Result\r\nContent-Type: " + mime + "\r\nContent-Length: " + bytes.length + "\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n\r\n";
        out.write(headers.getBytes("US-ASCII")); out.write(bytes); out.flush();
    }

    public final class VoiceBridge {
        @JavascriptInterface public void ready() { runOnUiThread(new Runnable() { @Override public void run() { status.setVisibility(View.GONE); }}); }
        @JavascriptInterface public void error(final String message) { showError("Não foi possível abrir o jogo neste tablet:\n" + message); }
        @JavascriptInterface public void speak(final String message) { runOnUiThread(new Runnable() { @Override public void run() {
            if (!foreground || isFinishing()) return;
            pendingVoice = message.length() > 3000 ? message.substring(0, 3000) : message;
            if (tts == null) tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override public void onInit(int result) {
                    if (tts == null || isFinishing()) return;
                    if (result == TextToSpeech.SUCCESS) {
                        int language = tts.setLanguage(new Locale("pt", "BR"));
                        voiceReady = language >= 0;
                        tts.setSpeechRate(0.85f);
                        sayPending();
                    }
                }
            });
            else sayPending();
        }}); }
        @JavascriptInterface public void stop() { runOnUiThread(new Runnable() { @Override public void run() { stopVoice(); }}); }
    }

    private void sayPending() { if (voiceReady && foreground && pendingVoice != null && tts != null) { tts.speak(pendingVoice, TextToSpeech.QUEUE_FLUSH, null); pendingVoice = null; } }
    private void stopVoice() { pendingVoice = null; if (tts != null) tts.stop(); }
    @Override protected void onResume() { super.onResume(); foreground = true; if (web != null) { web.resumeTimers(); web.onResume(); } }
    @Override protected void onPause() { foreground = false; stopVoice(); if (web != null) { web.onPause(); web.pauseTimers(); } super.onPause(); }
    @Override public void onConfigurationChanged(Configuration config) { super.onConfigurationChanged(config); web.loadUrl("javascript:if(window.PatrulhaViewport){window.PatrulhaViewport();}"); }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() {
        closed = true;
        if (server != null) try { server.close(); } catch (IOException ignored) { }
        if (pool != null) pool.shutdownNow();
        if (web != null) { web.removeJavascriptInterface("PatrulhaAndroid"); web.destroy(); }
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        super.onDestroy();
    }
}
