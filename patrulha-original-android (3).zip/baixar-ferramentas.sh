#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p toolchain
if [ ! -s toolchain/build-tools.zip ]; then
  curl --fail --location --retry 2 --connect-timeout 20 --max-time 180 \
    https://dl.google.com/android/repository/build-tools_r35_linux.zip \
    -o toolchain/build-tools.zip
fi
unzip -q -o toolchain/build-tools.zip -d toolchain
if [ ! -s toolchain/android.jar ]; then
  if curl --fail --location --connect-timeout 20 --max-time 120 \
      https://dl.google.com/android/repository/android-17_r03.zip \
      -o toolchain/platform-17.zip; then
    unzip -q -o toolchain/platform-17.zip -d toolchain/platform
    find toolchain/platform -name android.jar -exec cp '{}' toolchain/android.jar \;
  else
    curl --fail --location --retry 2 --connect-timeout 20 --max-time 120 \
      https://raw.githubusercontent.com/Sable/android-platforms/master/android-17/android.jar \
      -o toolchain/android.jar
  fi
fi
test -s toolchain/android.jar
printf 'Ferramentas Android e android.jar preparados.\n'
