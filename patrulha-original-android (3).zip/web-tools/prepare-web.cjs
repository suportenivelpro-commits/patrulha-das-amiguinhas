/* Build the real game as ES5, retaining its TSX, art and game engines. */
const fs = require('fs');
const path = require('path');
const webpack = require('webpack');
const postcss = require('postcss');
const tailwind = require('tailwindcss');
const nested = require('postcss-nested');
const presetEnv = require('postcss-preset-env');
const autoprefixer = require('autoprefixer');
const acorn = require('acorn');
const TerserPlugin = require('terser-webpack-plugin');
const sourceRoot = path.resolve(process.argv[2] || '../..');
const tools = __dirname;
const kit = path.dirname(tools);
const stage = path.join(tools, 'staging');
const assets = path.join(kit, 'assets');
function files(dir) { return fs.readdirSync(dir, {withFileTypes:true}).flatMap(e => e.isDirectory() ? files(path.join(dir,e.name)) : [path.join(dir,e.name)]); }
function write(name, content) { fs.mkdirSync(path.dirname(name),{recursive:true}); fs.writeFileSync(name,content); }
function runWebpack(config) { return new Promise((resolve,reject) => webpack(config,(err,stats) => err ? reject(err) : stats.hasErrors() ? reject(new Error(stats.toString({all:false,errors:true}))) : resolve(stats))); }

async function main() {
  if (!fs.existsSync(path.join(sourceRoot,'src/components/game/Game.tsx'))) throw new Error('O codigo original do jogo nao foi encontrado.');
  fs.rmSync(stage,{recursive:true,force:true}); fs.mkdirSync(stage,{recursive:true});
  fs.cpSync(path.join(sourceRoot,'src'),path.join(stage,'src'),{recursive:true});
  fs.mkdirSync(assets,{recursive:true});
  if (fs.existsSync(path.join(sourceRoot,'public'))) fs.cpSync(path.join(sourceRoot,'public'),assets,{recursive:true});
  const {parse,formatRgb,interpolate} = await import('culori');
  const color = value => value.replace(/oklch\([^()]+\)/g,m => { const c=parse(m); if(!c) throw new Error('Cor nao interpretada: '+m); return formatRgb(c); });
  let originalCss = color(fs.readFileSync(path.join(stage,'src/styles.css'),'utf8'));
  const globals = {};
  postcss.parse(originalCss).walkDecls(d => { if(d.prop.startsWith('--') && (d.parent.selector === ':root' || d.parent.name === 'theme')) globals[d.prop]=d.value; });
  function substitute(value, scope = globals) {
    for(let i=0;i<30 && /var\(/.test(value);i++) value=value.replace(/var\((--[\w-]+)(?:,\s*([^()]*))?\)/g,(_,name,fallback) => scope[name] === undefined ? fallback || '0' : scope[name]);
    return value;
  }
  for(let i=0;i<8;i++) for(const key of Object.keys(globals)) globals[key]=substitute(globals[key]);
  const tint={};
  for(const name of ['rose','lilac','turquoise','sun','mint','coral']) {const c=globals['--'+name];tint[c]=formatRgb(interpolate([c,'white'],'oklab')(.7));}
  for(const file of files(path.join(stage,'src')).filter(f=>/\.[jt]sx?$/.test(f))) {
    let s=color(fs.readFileSync(file,'utf8'));
    s=s.replace(/var\((--[\w-]+)\)/g,(all,name) => globals[name] || all);
    s=s.replace(/\[\s*["']--btn["']\s+as\s+string\s*\]/g,'"backgroundColor"');
    s=s.replace(/<image\s+href=/g,'<image xlinkHref=');
    const columns='style={{ gridTemplateColumns: `repeat(${level.size}, minmax(0, 1fr))` }}';
    s=s.replace(columns,'data-legacy-columns={level.size} '+columns);
    s=s.replace(/new RegExp\(`\(\$\{escaped\.join\("\|"\)\}\)`,\s*"u"\)/g,'new RegExp(`(${escaped.join("|")})`)');
    s=s.replace('o.connect(g).connect(ctx.destination);','o.connect(g); g.connect(ctx.destination);');
    s=s.replace(/\b(transform|transition|animation(?:Delay|Duration|IterationCount)?)\s*:/g,(_,name)=>'webkit'+name[0].toUpperCase()+name.slice(1)+':');
    s=s.replace(/(^|[^-])((?:repeating-)?linear-gradient)\((?:(\d+)deg\s*,)?/g,(_,before,kind,angle)=>before+'-webkit-'+kind+'('+(angle===undefined?'':((450-Number(angle))%360)+'deg,'));
    if(s.includes('`color-mix(in oklab, ${h.color} 30%, white)`')) {
      s=s.replaceAll('`color-mix(in oklab, ${h.color} 30%, white)`','legacyTint(h.color)');
      s+='\nfunction legacyTint(c: string) { return ('+JSON.stringify(tint)+' as Record<string,string>)[c] || c; }\n';
    }
    s=s.replace(/^import\s+["']\.\/styles\.css["'];?\s*$/m,'');
    write(file,s);
  }
  const gameText=fs.readFileSync(path.join(stage,'src/components/game/GameText.tsx'),'utf8');
  if(/new RegExp[^;]+,\s*["']u["']/.test(gameText)) throw new Error('Expressao Unicode sem conversao.');
  // Replace the modern CSS brightness filter by pre-rendered black SVG artwork.
  const textFile=path.join(stage,'src/components/game/GameText.tsx');
  write(textFile,gameText.replace('({ text }: { text: string })','({ text, silhouette = false }: { text: string; silhouette?: boolean })').replace('src={ILLUSTRATIONS[part]}','src={silhouette ? ILLUSTRATIONS[part].replace("/illustrations/", "/illustrations/black/") : ILLUSTRATIONS[part]}'));
  const challengeFile=path.join(stage,'src/components/game/minigames/ChallengeGame.tsx');
  let challenge=fs.readFileSync(challengeFile,'utf8').replace('<GameText text={token.icon} />','<GameText text={token.icon} silhouette={token.silhouette} />').replace('style={{ filter: token.silhouette ? "brightness(0)" : undefined }}','');
  write(challengeFile,challenge);
  // The animated puppy overlaps the ladder. Keep the decorative artwork out
  // of hit testing and paint the ladder controls above it in the Android build.
  const kittenFile=path.join(stage,'src/components/game/minigames/KittenGame.tsx');
  let kitten=fs.readFileSync(kittenFile,'utf8');
  const ladder='className="absolute bottom-0 left-[58%]';
  const puppy='className="absolute left-[62%]';
  if(!kitten.includes(ladder) || !kitten.includes(puppy)) throw new Error('Revise a protecao dos toques na escada: o fonte original mudou.');
  kitten=kitten.replace(ladder,'className="legacy-kitten-ladder absolute bottom-0 left-[58%]').replace(puppy,'className="legacy-kitten-hero absolute left-[62%]');
  write(kittenFile,kitten);
  require('./tablet-adapter.cjs')(stage);
  const levels=fs.readFileSync(path.join(stage,'src/game/challenge-levels.ts'),'utf8');
  const count=(levels.match(/"kind":/g)||[]).length;
  if(count!==42) throw new Error('O catalogo original mudou: revise a contagem antes de gerar o APK.');

  let sheet=postcss.parse(originalCss);
  sheet.walkAtRules(r => {
    if(['theme','custom-variant','source','import'].includes(r.name)) r.remove();
    else if(r.name==='utility') { const rule=postcss.rule({selector:'.'+r.params}); for(const node of [...r.nodes]) rule.append(node.clone()); r.replaceWith(rule); }
  });
  const themeColors={};
  for(const [key,value] of Object.entries(globals)) if(key.startsWith('--color-')) themeColors[key.slice(8)]=value;
  // Tailwind 3 emits a stylesheet that can be lowered for legacy WebKit.
  const config={content:[path.join(stage,'src/**/*.{ts,tsx}')],theme:{extend:{colors:themeColors,fontFamily:{display:['Baloo 2','Fredoka','sans-serif'],sans:['Fredoka','sans-serif']},opacity:{45:'.45',85:'.85'},minHeight:{14:'3.5rem',16:'4rem',20:'5rem',24:'6rem',36:'9rem'}}},corePlugins:{container:false}};
  const result=await postcss([tailwind(config),nested()]).process('@tailwind base;\n@tailwind components;\n@tailwind utilities;\n'+sheet.toString(),{from:undefined});
  const lowered=postcss.parse(result.css);
  // Resolve root variables and utility-local variables before removing them.
  const defaults={...globals};
  lowered.walkRules(r => { if(/^(\*|::before|::after|:root)/.test(r.selector)) r.walkDecls(d=>{if(d.prop.startsWith('--') && !d.prop.startsWith('--color')) defaults[d.prop]=d.value;}); });
  lowered.walkRules(r => {
    const own={...defaults};
    r.each(d=>{if(d.type==='decl' && d.prop.startsWith('--')) own[d.prop]=d.value;});
    for(let i=0;i<8;i++) for(const key of Object.keys(own)) own[key]=substitute(own[key],own);
    r.walkDecls(d=>{if(d.prop.startsWith('--')) d.remove(); else d.value=substitute(d.value,own);});
  });
  lowered.walkDecls(d=>{
    if(d.prop==='justify-content' && d.value==='safe center') d.value='center';
    if(d.prop==='padding-top' && d.value.includes('env(')) d.value='12px';
    if(d.value.includes('repeating-conic-gradient')) d.value='radial-gradient(circle,#fff,transparent)';
  });
  const css=await postcss([presetEnv({stage:0,browsers:['Android 4.2'],preserve:false,features:{'custom-properties':false,'has-pseudo-class':false}}),autoprefixer({overrideBrowserslist:['Android 4.2']})]).process(lowered.toString(),{from:undefined});
  let finalCss=css.css+'\n'+fs.readFileSync(path.join(tools,'legacy-layout.css'),'utf8');
  // Use WOFF (not WOFF2) fonts supported by the tablet's WebKit.
  fs.mkdirSync(path.join(assets,'fonts'),{recursive:true});
  for(const [family,display,weights] of [['baloo-2','Baloo 2',[600,800]],['fredoka','Fredoka',[400,600]]]) {
    const dir=path.join(tools,'node_modules/@fontsource',family,'files');
    for(const weight of weights) for(const subset of ['latin']) {
      const name=family+'-'+subset+'-'+weight+'-normal.woff';
      if(fs.existsSync(path.join(dir,name))) {
        fs.mkdirSync(path.join(assets,'fonts'),{recursive:true});fs.copyFileSync(path.join(dir,name),path.join(assets,'fonts',name));
        finalCss+='\n@font-face{font-family:"'+display+'";font-style:normal;font-weight:'+weight+';src:url("fonts/'+name+'") format("woff");}';
      }
    }
  }
  write(path.join(assets,'game.css'),finalCss);
  fs.copyFileSync(path.join(tools,'prelude.js'),path.join(assets,'prelude.js'));
  acorn.parse(fs.readFileSync(path.join(assets,'prelude.js'),'utf8'),{ecmaVersion:5});
  let notices='Componentes incluidos na versao Android da Patrulha das Amiguinhas.\n';
  for(const name of ['preact','core-js','whatwg-fetch','pepjs','abortcontroller-polyfill','clsx','tailwind-merge']) {
    const directory=path.join(tools,'node_modules',name);
    const pkg=JSON.parse(fs.readFileSync(path.join(directory,'package.json'),'utf8'));
    notices+='\n\n=== '+pkg.name+' '+pkg.version+' ===\n';
    for(const file of fs.readdirSync(directory).filter(n=>/^licen[cs]e(?:\..*)?$/i.test(n))) notices+=fs.readFileSync(path.join(directory,file),'utf8')+'\n';
  }
  write(path.join(assets,'THIRD-PARTY-LICENSES.txt'),notices);
  for(const family of ['baloo-2','fredoka']) {
    const license=path.join(tools,'node_modules/@fontsource',family,'LICENSE');
    if(fs.existsSync(license)) fs.copyFileSync(license,path.join(assets,'fonts','LICENSE-'+family+'.txt'));
  }
  const common={mode:'production',context:tools,target:['web','es5'],resolve:{extensions:['.tsx','.ts','.jsx','.js'],modules:[path.join(tools,'node_modules'),'node_modules'],alias:{'@':path.join(stage,'src'),'react$':require.resolve('preact/compat'),'react-dom$':require.resolve('preact/compat'),'react-dom/client$':path.join(tools,'react-client.js'),'react/jsx-runtime$':require.resolve('preact/jsx-runtime'),'react/jsx-dev-runtime$':require.resolve('preact/jsx-runtime')}},module:{rules:[{test:/\.[cm]?[jt]sx?$/,exclude:/node_modules\/(core-js|regenerator-runtime)/,use:{loader:require.resolve('babel-loader'),options:{babelrc:false,configFile:false,presets:[[require.resolve('@babel/preset-env'),{targets:{android:'4.2'},modules:false}],[require.resolve('@babel/preset-react'),{runtime:'automatic',importSource:'preact'}],require.resolve('@babel/preset-typescript')]}}}]},optimization:{minimize:true,minimizer:[new TerserPlugin({extractComments:false,terserOptions:{ecma:5,compress:{ecma:5},format:{ascii_only:true,comments:false}}})]},devtool:false,performance:{hints:false},output:{environment:{arrowFunction:false,const:false,destructuring:false,dynamicImport:false,forOf:false,module:false},iife:true}};
  await runWebpack({...common,entry:path.join(tools,'bootstrap.js'),output:{...common.output,path:assets,filename:'game.js'}});
  acorn.parse(fs.readFileSync(path.join(assets,'game.js'),'utf8'),{ecmaVersion:5,sourceType:'script'});
  const html='<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Patrulha das Amiguinhas</title><link rel="stylesheet" href="game.css"></head><body><div id="loading" style="padding:16px;font-family:sans-serif">Abrindo a aventura…</div><div id="root"></div><script src="prelude.js"></script><script src="game.js"></script></body></html>';
  write(path.join(assets,'index.html'),html);
  write(path.join(kit,'dist/web-verificado.txt'),'Codigo do projeto original preservado.\n8 minijogos e 42 desafios.\nBundle JavaScript validado como ES5.\nTeste no tablet fisico ainda necessario.\n');
  console.log('Jogo original preparado: 50 missoes e bundle ES5.');
}
main().catch(error=>{console.error(error);process.exitCode=1;});
