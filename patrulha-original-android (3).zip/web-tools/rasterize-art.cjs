const fs=require('fs'),path=require('path'),sharp=require('sharp');
const root=path.resolve(__dirname,'../assets/illustrations');
async function convert(dir){
  let count=0;
  for(const item of fs.readdirSync(dir,{withFileTypes:true})){
    const file=path.join(dir,item.name);
    if(item.isDirectory()) count+=await convert(file);
    else if(item.name.endsWith('.svg')){
      await sharp(file,{density:192}).resize(192,192,{fit:'contain',background:{r:0,g:0,b:0,alpha:0}}).png().toFile(file.slice(0,-4)+'.png');
      count++;
    }
  }
  return count;
}
convert(root).then(count=>console.log(count+' ilustracoes rasterizadas em PNG local para Android 4.2.2.')).catch(error=>{console.error(error);process.exitCode=1;});
