const fs=require('fs'),path=require('path'),assert=require('assert');
const {initLegacyBrowser,stableStyle,classicBoxStyle}=require('./browser-test-config.cjs');
const out=path.resolve(__dirname,'../dist/layout-tablet');
function catalog(){
  const cache=new Map();
  function load(file){
    if(cache.has(file)) return cache.get(file).exports;
    const module={exports:{}};cache.set(file,module);
    const {code}=require('@babel/core').transformFileSync(file,{configFile:false,babelrc:false,presets:[[require.resolve('@babel/preset-env'),{targets:{node:'24'},modules:'commonjs'}],require.resolve('@babel/preset-typescript')]});
    const localRequire=name=>{if(!name.startsWith('./')) throw new Error('Dependencia inesperada no catalogo: '+name);return load(path.resolve(path.dirname(file),name+'.ts'));};
    new Function('module','exports','require',code)(module,module.exports,localRequire);
    return module.exports;
  }
  return load(path.resolve(__dirname,'staging/src/game/data.ts'));
}
async function measure(page,label){
  await page.evaluate(()=>window.PatrulhaTabletLayout());
  await page.locator('img.game-illustration').evaluateAll(async images=>{
    await Promise.all(images.map(img=>img.complete?Promise.resolve():new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(new Error(img.src));})));
  });
  const result=await page.evaluate(()=>{
    const problems=[];
    const width=window.innerWidth,height=window.innerHeight;
    if(document.documentElement.scrollWidth>width+2) problems.push('Rolagem horizontal na pagina');
    for(const img of document.querySelectorAll('img.game-illustration')){
      const r=img.getBoundingClientRect();
      if(!img.src.endsWith('.png')||!img.complete||!img.naturalWidth) problems.push('Ilustracao nao carregou como PNG: '+img.src);
      if(r.width<13||r.height<13||Math.abs(r.width-r.height)>2) problems.push('Ilustracao achatada ou pequena: '+img.alt+' '+r.width+'x'+r.height);
    }
    for(const button of document.querySelectorAll('button')){
      const r=button.getBoundingClientRect();
      if(r.width&&r.height&&(r.left < -2 || r.right > width+2)) problems.push('Controle fora da largura: '+(button.getAttribute('aria-label')||button.textContent));
    }
    const board=document.querySelector('.legacy-map-board');
    if(board){
      const bounds=board.getBoundingClientRect();
      if(bounds.height<278||bounds.height>462) problems.push('Altura do mapa: '+bounds.height);
      for(const node of board.querySelectorAll('.legacy-map-node')){
        const r=node.getBoundingClientRect();
        if(r.left<bounds.left-2||r.right>bounds.right+2||r.top<bounds.top-2||r.bottom>bounds.bottom+2) problems.push('Missao cortada no mapa: '+node.getAttribute('aria-label'));
      }
    }
    for(const grid of document.querySelectorAll('.grid')){
      const items=Array.from(grid.children).map(node=>node.getBoundingClientRect()).filter(r=>r.width&&r.height);
      for(let a=0;a<items.length;a++) for(let b=a+1;b<items.length;b++){
        const x=Math.min(items[a].right,items[b].right)-Math.max(items[a].left,items[b].left);
        const y=Math.min(items[a].bottom,items[b].bottom)-Math.max(items[a].top,items[b].top);
        if(x>2&&y>2) problems.push('Pecas sobrepostas numa grade');
      }
    }
    return {width,height,problems,pictures:document.querySelectorAll('img.game-illustration').length};
  });
  assert.deepEqual(result.problems,[],label+': '+result.problems.join('; '));
  return result;
}
async function run(browser,url){
  fs.mkdirSync(out,{recursive:true});
  const {MISSIONS,CHAPTERS,HEROES}=catalog();
  assert.equal(MISSIONS.length,50);
  const completed={stars:Object.fromEntries(MISSIONS.map(m=>[m.id,1])),medals:[],sound:false};
  const levelsSource=fs.readFileSync(path.resolve(__dirname,'staging/src/game/challenge-levels.ts'),'utf8');
  const levels=JSON.parse(levelsSource.slice(levelsSource.indexOf('= [')+2,levelsSource.indexOf('\n];')+2));
  const kinds=new Map(levels.map(level=>[level.id,level.kind]));
  const shapes=new Set();
  const representative=MISSIONS.filter(m=>{
    let shape=m.game;
    if(shape==='challenge'){
      shape='challenge-'+kinds.get(m.challengeId);
    }
    if(shapes.has(shape))return false;shapes.add(shape);return true;
  });
  const report=[];
  for(const viewport of [{width:600,height:984},{width:1024,height:560}]){
    const context=await browser.newContext({viewport,deviceScaleFactor:1});
    const page=await context.newPage();
    const errors=[];
    page.on('pageerror',e=>errors.push(String(e)));
    page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
    await page.addInitScript(initLegacyBrowser,completed);
    await page.clock.install();
    const tag=viewport.width+'x'+viewport.height;
    async function openHub(){
      await page.goto(url);
      await page.addStyleTag({content:stableStyle+classicBoxStyle});
      await page.getByRole('button',{name:/Jogar/}).waitFor();
      await page.clock.runFor(200);
      await page.getByRole('button',{name:/Jogar/}).click();
      await page.getByRole('button',{name:/Mapa/}).waitFor();
    }
    async function capture(label){
      report.push({label,...await measure(page,label)});
      await page.screenshot({path:path.join(out,tag+'-'+label+'.png')});
    }
    try{
      await openHub();await capture('central');
      await page.getByRole('button',{name:/Equipe/,exact:true}).click();await capture('equipe');
      await openHub();await page.getByRole('button',{name:/Medalhas/,exact:true}).click();await capture('medalhas');
      await openHub();await page.getByRole('button',{name:/Voz e ajustes/}).click();await capture('ajustes');
      await openHub();await page.getByRole('button',{name:/Mapa/,exact:true}).click();
      for(let chapter=0;chapter<CHAPTERS.length;chapter++){
        await page.locator('#chapter-select').selectOption(String(chapter));
        await page.clock.runFor(100);
        await capture('mapa-'+(chapter+1));
      }
      for(const mission of viewport.width===600?MISSIONS:representative){
        await openHub();await page.getByRole('button',{name:/Mapa/,exact:true}).click();
        const chapter=CHAPTERS.findIndex(c=>c.missions.includes(mission.id));
        await page.locator('#chapter-select').selectOption(String(chapter));
        await page.getByRole('button',{name:mission.title,exact:true}).click();
        await page.getByRole('button',{name:/Vamos ajudar/}).click();
        await measure(page,'escolha-'+mission.id);
        const hero=HEROES.find(h=>h.id===mission.hero);
        await page.getByRole('button',{name:new RegExp('\\b'+hero.name+'\\b')}).click();
        await page.clock.runFor(13000);
        await page.locator('[data-tablet-game]:not([data-tablet-game="drive"])').waitFor({timeout:5000});
        await capture('missao-'+mission.id);
      }
      assert.deepEqual(errors,[],errors.join('\n'));
    }catch(error){
      await page.screenshot({path:path.join(out,tag+'-FALHA.png')}).catch(()=>{});
      fs.writeFileSync(path.join(out,tag+'-FALHA.txt'),String(error)+'\n'+errors.join('\n')+'\n'+await page.locator('body').innerText());
      throw error;
    }finally{await context.close();}
  }
  fs.writeFileSync(path.join(out,'relatorio.json'),JSON.stringify(report,null,2));
  console.log('Layout: 50 missoes em retrato, '+representative.length+' tipos em paisagem e todos os mapas verificados com caixas WebKit classicas.');
}
module.exports={run,catalog};
