/* ES5: size the actual WebView viewport, not the physical panel or modern dvh. */
(function(window,document){
  function height(node){
    if(!node)return 0;
    var rect=node.getBoundingClientRect();
    return typeof rect.height==='number'?rect.height:rect.bottom-rect.top;
  }
  function setPixels(node,property,value){
    var text=Math.round(value)+'px';
    if(node.style[property]!==text) node.style[property]=text;
  }
  window.PatrulhaTabletLayout=function(force){
    var i,node,style,size;
    var pictures=document.querySelectorAll('img.game-illustration');
    for(i=0;i<pictures.length;i++){
      node=pictures[i];
      if(node.__patrulhaSized&&!force)continue;
      style=window.getComputedStyle(node,null);
      size=Math.max(14,Math.min(160,parseFloat(style.fontSize)||32));
      setPixels(node,'width',size);setPixels(node,'height',size);
      node.__patrulhaSized=true;
    }
    var toolbar=document.querySelector('.game-toolbar');
    var nav=document.querySelector('.legacy-chapter-nav');
    var board=document.querySelector('.legacy-map-board');
    if(nav){
      var select=nav.querySelector('select');
      if(select) setPixels(select,'width',Math.max(120,nav.clientWidth-112));
    }
    if(board){
      var summary=document.querySelector('.legacy-chapter-summary');
      var available=window.innerHeight-height(toolbar)-height(nav)-height(summary)-100;
      var boardHeight=Math.max(280,Math.min(460,board.clientWidth*.78,available));
      setPixels(board,'height',boardHeight);
    }
    var slot=document.querySelector('.legacy-play-slot');
    if(slot) setPixels(slot,'height',Math.max(280,window.innerHeight-height(toolbar)-8));
  };
})(window,document);
