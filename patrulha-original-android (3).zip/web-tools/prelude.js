(function(window, document) {
  window.MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
  var NativeEvent = window.Event;
  try { new NativeEvent('test'); } catch (error) {
    window.Event = function(name, options) {
      var event = document.createEvent('Event');
      options = options || {};
      event.initEvent(name, !!options.bubbles, !!options.cancelable);
      return event;
    };
    if (NativeEvent && NativeEvent.prototype) window.Event.prototype = NativeEvent.prototype;
  }
  try { new window.CustomEvent('test'); } catch (error) {
    window.CustomEvent = function(name, options) {
      options = options || {};
      var event = document.createEvent('CustomEvent');
      event.initCustomEvent(name, !!options.bubbles, !!options.cancelable, options.detail);
      return event;
    };
    window.CustomEvent.prototype = window.Event.prototype;
  }
})(window, document);
