function initLegacyBrowser(progress){
  window.fetch=undefined;window.PointerEvent=undefined;
  window.PatrulhaAndroid={ready(){},error(message){console.error(message);},speak(){},stop(){}};
  Object.defineProperty(window,'speechSynthesis',{value:undefined,writable:true,configurable:true});
  if(progress) localStorage.setItem('patrulha-amiguinhas-v1',JSON.stringify(progress));
}
// Exercise classic WebKit box layout in Chromium, without freezing game timers.
const stableStyle='*,*::before,*::after{animation:none!important;-webkit-animation:none!important;transition:none!important;-webkit-transition:none!important;scroll-behavior:auto!important;}';
const classicBoxStyle='.flex{display:-webkit-box!important}.grid>.flex{display:-webkit-box!important}.flex-wrap,.game-toolbar,.legacy-map-screen,.legacy-chapter-nav,.legacy-chapter-summary{display:block!important}';
module.exports={initLegacyBrowser,stableStyle,classicBoxStyle};
