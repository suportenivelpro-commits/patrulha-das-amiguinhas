const fs=require('fs'),path=require('path'),http=require('http');
const {chromium}=require('playwright');
const {initLegacyBrowser,stableStyle}=require('./browser-test-config.cjs');
const root=path.resolve(__dirname,'../assets');
const kit=path.dirname(__dirname);
const errors=[];
const server=http.createServer((req,res)=>{
  const name=decodeURIComponent(req.url.split('?')[0]);
  const file=path.resolve(root,'.'+(name==='/'?'/index.html':name));
  if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
  fs.readFile(file,(err,data)=>{
    if(err){res.writeHead(name==='/favicon.ico'?204:404);res.end();return;}
    const ext=path.extname(file);
    res.setHeader('Content-Type',({'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.woff':'font/woff','.ttf':'font/ttf'})[ext]||'application/octet-stream');
    res.end(data);
  });
});
async function main(){
  fs.mkdirSync(path.join(kit,'dist'),{recursive:true});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const browser=await chromium.launch({headless:true});
  let page;
  try {
    page=await browser.newPage({viewport:{width:600,height:984},deviceScaleFactor:1});
    page.on('pageerror',err=>{errors.push(String(err));console.error('Erro JavaScript: '+String(err));});
    page.on('console',msg=>{if(msg.type()==='error'){errors.push(msg.text());console.error('Console do jogo: '+msg.text());}});
    await page.addInitScript(initLegacyBrowser);
    const url='http://127.0.0.1:'+server.address().port+'/';
    await page.goto(url);
    // Freeze decorative motion only in this test page. Playwright requires stable
    // elements for icon screenshots and clicks; the APK keeps its animations.
    await page.addStyleTag({content:stableStyle});
    await page.getByRole('button',{name:/Jogar/}).waitFor({timeout:30000});
    await page.evaluate(()=>document.fonts.ready);
    const puppies=await page.locator('svg[aria-label="Luna"],svg[aria-label="Mel"],svg[aria-label="Bella"],svg[aria-label="Lili"],svg[aria-label="Nina"]').count();
    if(puppies!==5) throw new Error('A tela inicial nao exibe as cinco personagens originais.');
    fs.mkdirSync(path.join(kit,'dist'),{recursive:true});
    fs.mkdirSync(path.join(kit,'res/drawable-mdpi'),{recursive:true});
    await page.screenshot({path:path.join(kit,'dist/01-tela-original.png'),animations:'disabled'});
    await page.locator('svg[aria-label="Luna"]').first().screenshot({path:path.join(kit,'res/drawable-mdpi/ic_launcher.png'),omitBackground:true,animations:'disabled'});
    await page.getByRole('button',{name:/Jogar/}).click();
    await page.getByText(/0\/50 missões/).waitFor();
    await page.getByRole('button',{name:/Mapa/}).click();
    await page.getByRole('button',{name:'Gatinho no Alto',exact:true}).waitFor();
    await page.screenshot({path:path.join(kit,'dist/02-mapa-original.png')});
    await page.getByRole('button',{name:'Gatinho no Alto',exact:true}).click();
    await page.getByRole('button',{name:/Vamos ajudar/}).click();
    await page.getByRole('button',{name:/Mel/}).click();
    await page.getByRole('button',{name:'Esquerda',exact:true}).waitFor({timeout:12000});
    await page.screenshot({path:path.join(kit,'dist/03-viagem-original.png')});
    await page.getByRole('button',{name:'🪜',exact:true}).waitFor({timeout:25000});
    await page.screenshot({path:path.join(kit,'dist/04-resgate-original.png')});
    await page.getByRole('button',{name:'🪜',exact:true}).click();
    for(let n=1;n<=5;n++) await page.getByRole('button',{name:'Degrau '+n,exact:true}).click();
    await page.getByRole('heading',{name:'Missão cumprida!',exact:true}).waitFor({timeout:12000});
    await page.screenshot({path:path.join(kit,'dist/05-missao-concluida.png')});
    const saved=await page.evaluate(()=>Object.keys(localStorage).some(key=>{try{return JSON.parse(localStorage.getItem(key)).stars.gatinho>0;}catch{return false;}}));
    if(!saved) throw new Error('O progresso da missao nao foi salvo.');
    if(errors.length) throw new Error('Erros no navegador: '+errors.join('\n'));
    fs.appendFileSync(path.join(kit,'dist/web-verificado.txt'),'Teste Chromium: titulo com cinco personagens, mapa com 50 missoes, escolha de Mel, viagem, resgate do gatinho e progresso salvos.\nEste teste de navegador nao substitui o teste Android 4.2.2 no tablet.\n');
    console.log('Fluxo grafico original percorrido; capturas e progresso verificados.');
    await require('./layout-test.cjs').run(browser,url);
  } catch(error) {
    if(page) {
      try {
        const body=await page.locator('body').innerText({timeout:3000});
        const diagnostic={error:String(error),javascriptErrors:errors,body};
        fs.writeFileSync(path.join(kit,'dist/erro-do-teste.json'),JSON.stringify(diagnostic,null,2));
        console.error('Diagnostico da tela: '+JSON.stringify(diagnostic));
        await page.screenshot({path:path.join(kit,'dist/erro-do-teste.png'),timeout:5000});
      } catch(diagnosticError) {console.error('Falha ao registrar a tela: '+String(diagnosticError));}
    }
    throw error;
  } finally {await browser.close();server.close();}
}
main().catch(err=>{console.error(err);server.close();process.exitCode=1;});
