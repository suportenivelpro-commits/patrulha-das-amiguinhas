import { render } from 'preact';
export function createRoot(container) {
  return { render: function(node) { render(node, container); }, unmount: function() { render(null, container); } };
}
