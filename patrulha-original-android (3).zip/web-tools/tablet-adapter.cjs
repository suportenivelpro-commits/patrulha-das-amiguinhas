const fs=require('fs'),path=require('path');
function once(source,from,to){
  if(!source.includes(from)) throw new Error('O fonte original mudou; revise o layout do tablet: '+from.slice(0,90));
  return source.replace(from,to);
}
function lowerGradients(source){
  let result='',at=0;
  const pattern=/-webkit-(?:repeating-)?linear-gradient\(/g;
  let match;
  while((match=pattern.exec(source))){
    let end=pattern.lastIndex,depth=1;
    for(;end<source.length&&depth;end++){
      if(source[end]==='(')depth++;else if(source[end]===')')depth--;
    }
    if(depth)break;
    const body=source.slice(pattern.lastIndex,end-1);
    const parts=[];let begin=0;depth=0;
    for(let i=0;i<=body.length;i++){
      if(body[i]==='(')depth++;else if(body[i]===')')depth--;
      if(i===body.length||(body[i]===','&&depth===0)){parts.push(body.slice(begin,i));begin=i+1;}
    }
    const classic=parts.flatMap(part=>{
      const stop=part.match(/^(.*?)\s+(-?[\d.]+(?:%|px|rem|em|vh|vw)?)\s+(-?[\d.]+(?:%|px|rem|em|vh|vw)?)\s*$/);
      return stop?[stop[1]+' '+stop[2],stop[1]+' '+stop[3]]:[part];
    }).join(',');
    result+=source.slice(at,match.index)+match[0]+classic+')';at=end;pattern.lastIndex=end;
  }
  return result+source.slice(at);
}
module.exports=function adaptTablet(stage){
  const gameFile=path.join(stage,'src/components/game/Game.tsx');
  let game=fs.readFileSync(gameFile,'utf8');
  game=once(game,'return <div className="game-app flex h-dvh','return <div data-screen={s.n} className="game-app flex h-dvh');
  game=once(game,'className="flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto px-3 pb-3"','className="legacy-map-screen flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto px-3 pb-3"');
  game=once(game,'className="flex shrink-0 items-center gap-2" aria-label="Capítulos"','className="legacy-chapter-nav flex shrink-0 items-center gap-2" aria-label="Capítulos"');
  game=once(game,'className="card-game flex shrink-0 items-center gap-3 px-4 py-2"','className="legacy-chapter-summary card-game flex shrink-0 items-center gap-3 px-4 py-2"');
  game=once(game,'className="card-game relative flex-1 overflow-hidden"','className="legacy-map-board card-game relative flex-1 overflow-hidden"');
  game=once(game,'<svg className="absolute inset-0 h-full w-full"','<svg className="legacy-map-art absolute inset-0 h-full w-full"');
  game=once(game,'className="absolute text-3xl"','className="legacy-map-decoration absolute text-3xl"');
  game=once(game,'className="absolute left-1/2 top-[45%]','className="legacy-map-base absolute left-1/2 top-[45%]');
  game=once(game,'className="absolute -translate-x-1/2 -translate-y-1/2 text-center"','className="legacy-map-node absolute -translate-x-1/2 -translate-y-1/2 text-center"');
  game=once(game,'{p.stars[m.id] ? <Stars n={p.stars[m.id]} size={16} /> : null}','{p.stars[m.id] ? <Stars n={p.stars[m.id]} size={16} /> : null}<span className="legacy-map-label" aria-hidden="true">{m.title}</span>');
  game=once(game,'className="grid flex-1 grid-cols-2 gap-4 overflow-auto p-4 sm:grid-cols-3 lg:grid-cols-5"','className="legacy-team-grid grid flex-1 grid-cols-2 gap-4 overflow-auto p-4 sm:grid-cols-3 lg:grid-cols-5"');
  game=once(game,'className="grid grid-cols-2 gap-3 sm:grid-cols-5"','className="legacy-choose-grid grid grid-cols-2 gap-3 sm:grid-cols-5"');
  game=game.replaceAll('className="min-h-0 flex-1 px-3 pb-3"','className="legacy-play-slot min-h-0 flex-1 px-3 pb-3"');
  fs.writeFileSync(gameFile,game);
  for(const name of ['Kitten','Fire','Vet','Bridge','Park','Garden','River','Memory','Challenge','Drive']){
    const file=path.join(stage,'src/components/game/minigames',name+'Game.tsx');
    let source=fs.readFileSync(file,'utf8');
    source=once(source,'<div className="flex h-full','<div data-tablet-game="'+name.toLowerCase()+'" className="flex h-full');
    fs.writeFileSync(file,source);
  }
  const illustrations=path.join(stage,'src/game/illustrations.ts');
  fs.writeFileSync(illustrations,fs.readFileSync(illustrations,'utf8').replace(/\.svg(["'])/g,'.png$1'));
  function lowerFiles(dir){
    for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
      const file=path.join(dir,entry.name);
      if(entry.isDirectory())lowerFiles(file);
      else if(/\.[jt]sx?$/.test(file))fs.writeFileSync(file,lowerGradients(fs.readFileSync(file,'utf8')));
    }
  }
  lowerFiles(path.join(stage,'src'));
};
module.exports.lowerGradients=lowerGradients;
