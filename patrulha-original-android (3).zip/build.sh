#!/usr/bin/env bash
# Build local, sem Gradle. Não acessa a rede.
set -euo pipefail
cd "$(dirname "$0")"
umask 077

ANDROID_JAR="${ANDROID_JAR:-$PWD/toolchain/android.jar}"
BUILD_TOOLS="${BUILD_TOOLS:-}"
if [ -z "$BUILD_TOOLS" ]; then
  while IFS= read -r candidate; do
    if [ -f "$(dirname "$candidate")/lib/d8.jar" ] && [ -f "$(dirname "$candidate")/lib/apksigner.jar" ]; then
      BUILD_TOOLS="$(dirname "$candidate")"
      break
    fi
  done < <(find "$PWD/toolchain" -type f -name aapt 2>/dev/null)
fi
if [ ! -s "$ANDROID_JAR" ] || [ -z "$BUILD_TOOLS" ] || [ ! -f "$BUILD_TOOLS/zipalign" ]; then
  printf '%s\n' 'Faltam as ferramentas Android. Prepare toolchain com baixar-ferramentas.sh ou defina ANDROID_JAR e BUILD_TOOLS.' >&2
  exit 1
fi

chmod u+x "$BUILD_TOOLS/aapt" "$BUILD_TOOLS/zipalign"
mkdir -p build/generated build/classes build/dex dist .private
find build/generated build/classes build/dex -type f -delete

"$BUILD_TOOLS/aapt" package -f -m \
  -M AndroidManifest.xml -S res -A assets -I "$ANDROID_JAR" \
  -J build/generated -F build/resources.ap_

find src build/generated -name '*.java' -print > build/sources.txt
# A imagem do ambiente tem o compilador como módulo, sem executável javac.
# D8 converte estes bytecodes para DEX compatível com Android API 17.
java -m jdk.compiler/com.sun.tools.javac.Main \
  -encoding UTF-8 -source 8 -target 8 -bootclasspath "$ANDROID_JAR" \
  -d build/classes @build/sources.txt

python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
base = Path('build/classes')
with ZipFile('build/classes.jar', 'w', ZIP_DEFLATED) as archive:
    for path in sorted(base.rglob('*.class')):
        archive.write(str(path), str(path.relative_to(base)))
PY

java -cp "$BUILD_TOOLS/lib/d8.jar" com.android.tools.r8.D8 \
  --min-api 17 --lib "$ANDROID_JAR" --output build/dex build/classes.jar

python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
with ZipFile('build/resources.ap_', 'r') as resources:
    with ZipFile('build/unsigned.apk', 'w', ZIP_DEFLATED) as apk:
        for entry in resources.infolist():
            apk.writestr(entry, resources.read(entry.filename))
        for dex in sorted(Path('build/dex').glob('*.dex')):
            apk.write(str(dex), dex.name)
PY

"$BUILD_TOOLS/zipalign" -f 4 build/unsigned.apk build/aligned.apk

if [ ! -s .private/signing.jks ]; then
  python3 - <<'PY'
import secrets
from pathlib import Path
Path('.private/password.txt').write_text(secrets.token_hex(24) + '\n')
PY
  keytool -genkeypair -noprompt -storetype JKS \
    -keystore .private/signing.jks -alias patrulha \
    -storepass:file .private/password.txt -keypass:file .private/password.txt \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -dname 'CN=Patrulha das Amiguinha, OU=Jogos educativos, O=Projeto local, C=BR'
fi

# A assinatura JAR/v1 é obrigatória em Android 4.2.2. O min-sdk 17
# faz o apksigner escolher os algoritmos aceitos por essa versão.
java -jar "$BUILD_TOOLS/lib/apksigner.jar" sign \
  --ks .private/signing.jks --ks-key-alias patrulha \
  --ks-pass file:.private/password.txt \
  --min-sdk-version 17 --v1-signing-enabled true \
  --v2-signing-enabled false --v3-signing-enabled false --v4-signing-enabled false \
  --out dist/patrulha-original-android-4.2.2.apk build/aligned.apk

java -jar "$BUILD_TOOLS/lib/apksigner.jar" verify \
  --verbose --min-sdk-version 17 --max-sdk-version 17 \
  dist/patrulha-original-android-4.2.2.apk | tee dist/assinatura-verificada.txt
"$BUILD_TOOLS/zipalign" -c 4 dist/patrulha-original-android-4.2.2.apk
"$BUILD_TOOLS/aapt" dump badging dist/patrulha-original-android-4.2.2.apk \
  > dist/manifest-verificado.txt
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
manifesto = Path('dist/manifest-verificado.txt').read_text()
assinatura = Path('dist/assinatura-verificada.txt').read_text()
assert "sdkVersion:'17'" in manifesto, 'minSdk do APK diferente de 17'
assert "targetSdkVersion:'17'" in manifesto, 'targetSdk do APK diferente de 17'
assert 'Verified using v1 scheme (JAR signing): true' in assinatura, 'APK sem assinatura v1 válida'
with ZipFile('dist/patrulha-original-android-4.2.2.apk') as apk:
    assert apk.read('classes.dex')[:8] == b'dex\n035\x00', 'DEX incompatível com Dalvik Android 4.2.2'
print('Verificado: minSdk 17, targetSdk 17, DEX 035 e assinatura v1 para API 17.')
PY
sha256sum dist/patrulha-original-android-4.2.2.apk > dist/SHA256SUMS.txt
printf '%s\n' 'APK criado: dist/patrulha-original-android-4.2.2.apk'
