# Patrulha Tablet — revisão para SM-T111M

Esta revisão compila o jogo gráfico do repositório original `suportenivelpro-commits/patrulha-das-amiguinhas`: cinco personagens, veículos, oito minijogos e 42 desafios, com as regras originais.

O Samsung Galaxy Tab 3 Lite tem painel de 7 polegadas, 600 × 1024 pixels. O espaço entregue ao WebView pode ser menor por causa das barras do sistema e da densidade configurada. Por isso o layout usa a largura e altura reais da janela, inclusive após girar o tablet.

## O que mudou

- Mapa com altura limitada, fundo de cor compatível, base e cinco pontos de missão agrupados; nomes legíveis nas missões.
- Botões sem a moldura padrão antiga do Android.
- Figuras originais convertidas para PNG local, com dimensões em pixels para evitar cortes e achatamento.
- Grades que preservam o tamanho dos desenhos; espaçamento separado para linhas e colunas.
- Barra superior, seletor de capítulos, escolha das heroínas e área dos minijogos ajustados para retrato e paisagem.
- Gradientes antigos com paradas de cor explícitas.

## Como gerar

1. Envie `patrulha-original-android.zip`, sem descompactar, para a raiz do repositório original, substituindo o arquivo anterior.
2. Confirme **Commit changes**. A rotina existente **Gerar APK Original** executará novamente; não é preciso alterá-la.
3. Baixe o artefato **Patrulha-Original-Android** quando a rotina concluir.
4. Confira as imagens em `layout-tablet/` e o `relatorio.json`. O APK se chama `patrulha-original-android-4.2.2.apk`.
5. Instale no tablet. O ícone desta revisão se chama **Patrulha Tablet**.

O identificador Android é separado do anterior, para permitir comparar os dois aplicativos sem desinstalar o antigo. O progresso local anterior não é importado automaticamente. A origem HTTP local também usa outra porta para os aplicativos coexistirem.

## Verificação e limites

O teste do GitHub conclui a primeira missão e verifica o progresso salvo. Em seguida confere as telas iniciais das 50 missões em retrato, um exemplar de cada tipo em paisagem, todos os mapas e as telas principais. Verifica carregamento e proporção das imagens, limites horizontais dos controles e sobreposição de peças nas grades. Essa inspeção não equivale a concluir as 50 missões.

A revisão de layout força as caixas CSS WebKit clássicas em Chromium. Isso ajuda a verificar o comportamento do layout antigo, mas ainda exige confirmação no WebKit real do Android 4.2.2. A nova compilação e essas verificações serão executadas no GitHub depois do envio do pacote. A conta online depende do HTTPS do sistema antigo e continua sem validação no aparelho.

As ilustrações e seus créditos são copiados de `public/`; a conversão para PNG mantém o desenho e sua licença. Preact, ES5, suporte a toques, fontes locais e narração Android continuam incluídos.

A assinatura de teste é gerada privadamente a cada execução e não é publicada. Para futuras atualizações que preservem o progresso dentro do mesmo aplicativo, será necessário manter uma chave de assinatura estável.
